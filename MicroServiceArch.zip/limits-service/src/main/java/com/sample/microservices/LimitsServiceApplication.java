package com.sample.microservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LimitsServiceApplication  {

	public static void main(String[] args) {
		SpringApplication.run(LimitsServiceApplication.class, args);
		
		//String regex = "[0-9](\\.[0-9]{1,2})";
		//String regex = "\\d{1,8}+(\\.?\\d{1,2})";
		//String regex = "\\d{1,8}\\.?\\d{1,2}";
	//	String regex = "(\\d{1,8})\\.?\\d{1,2}$";
		//String regex = "([0-9]{1,9})(\\.[0-9]{1,2}$)";
	//	String regex = "^[0-9]+(\\.[0-9]{1,2})?$";
		String regex = "(^[0-9]{1,8})(\\.[0-9]{1,2})?$";
	//	String regex = "([0-9]+){1,8}(\\.?\\d{1,2}$)";
	/*	System.out.println("12.33".matches(regex));
		System.out.println("2.0".matches(regex));
		System.out.println("0.03".matches(regex));
		System.out.println("13".matches(regex));
		System.out.println("123456789".matches(regex));
		System.out.println("123456789.3".matches(regex));
		System.out.println("12345678.3".matches(regex));
		System.out.println("------");
		System.out.println("2.034".matches(regex));
		System.out.println("0..12".matches(regex));
		System.out.println("s".matches(regex));
		System.out.println(".13".matches(regex));
		System.out.println("12.".matches(regex));
		System.out.println("10e5.4".matches(regex));
		System.out.println("2e10".matches(regex));
		System.out.println("2,34,223".matches(regex));
		System.out.println("2/3".matches(regex));
		
		System.out.println(MessageFormat.format("my string {0} ", 22))  ;*/
		
	}

}
