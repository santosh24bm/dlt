insert into exchange_value  (id, currency_from , currency_to, conversion_multiple,port)
values(101, 'USD','INR', 65,0);
insert into exchange_value (id, currency_from , currency_to, conversion_multiple,port)
values(102, 'EUR','INR', 75,1);
insert into exchange_value  (id, currency_from , currency_to, conversion_multiple,port)
values(103, 'AUD','INR', 85,1);