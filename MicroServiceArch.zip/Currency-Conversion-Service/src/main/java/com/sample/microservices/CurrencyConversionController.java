package com.sample.microservices;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class CurrencyConversionController {

	@GetMapping("/currency-exchange/from/{from}/to/{to}/quantity/{quantity}")
	public CurrencyConversionBean convertCurrency(@PathVariable String from, @PathVariable String to,
			@PathVariable BigDecimal quantity) {

		Map<String , String> variables = new HashMap<>();
		variables.put("from", from);
		variables.put("to", to);
		ResponseEntity<CurrencyConversionBean> response = new RestTemplate().getForEntity("http://localhost:8000/currency-exchange/from/{from}/to/{to}", 
				CurrencyConversionBean.class, variables);
		CurrencyConversionBean respnseObj = response.getBody();
		return new CurrencyConversionBean(respnseObj.getId(), from, to, respnseObj.getConversionMulitple(), quantity, quantity.multiply(respnseObj.getConversionMulitple()), 
				respnseObj.getPort());

	}

}
